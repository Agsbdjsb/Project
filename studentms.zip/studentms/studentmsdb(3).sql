-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2023 at 06:54 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_table`
--

CREATE TABLE `admin_table` (
  `ID` int(5) NOT NULL,
  `AdminName` varchar(120) NOT NULL,
  `Mobile_Number` bigint(10) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `User_Name` varchar(120) NOT NULL,
  `Password` varchar(200) NOT NULL,
  `Admin_Reg_Date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin_table`
--

INSERT INTO `admin_table` (`ID`, `AdminName`, `Mobile_Number`, `Email`, `User_Name`, `Password`, `Admin_Reg_Date`) VALUES
(1, 'Afaq Ahmed', 4354656561, 'afaqahmed@gmail.com', 'afaqahmed', 'd5158ce9d2e9898e636fe2531d036537', '2023-12-11 14:20:40');

-- --------------------------------------------------------

--
-- Table structure for table `classes_table`
--

CREATE TABLE `classes_table` (
  `ID` int(5) NOT NULL,
  `Class_Name` varchar(50) NOT NULL,
  `Section` varchar(20) NOT NULL,
  `Creation_Date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `classes_table`
--

INSERT INTO `classes_table` (`ID`, `Class_Name`, `Section`, `Creation_Date`) VALUES
(1, '1', 'A', '2022-01-13 05:42:14'),
(2, '1', 'B', '2022-01-13 05:42:35'),
(3, '2', 'A', '2022-01-13 05:42:41'),
(4, '2', 'B', '2022-01-13 05:42:47'),
(5, '3', 'A', '2022-01-13 05:42:52');

-- --------------------------------------------------------

--
-- Table structure for table `student_table`
--

CREATE TABLE `student_table` (
  `ID` int(10) NOT NULL,
  `Student_Name` varchar(200) NOT NULL,
  `Student_Email` varchar(200) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `DOB` date NOT NULL,
  `Student_ID` varchar(200) NOT NULL,
  `Father_Name` mediumtext DEFAULT NULL,
  `Mother_Name` mediumtext DEFAULT NULL,
  `Address` mediumtext DEFAULT NULL,
  `User_Name` varchar(200) NOT NULL,
  `Password` varchar(200) NOT NULL,
  `Image` varchar(200) DEFAULT NULL,
  `Date_of_Admission` timestamp NULL DEFAULT current_timestamp(),
  `Class_ID` int(5) DEFAULT NULL,
  `Contact_Number` varchar(15) NOT NULL,
  `Alternate_Number` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `student_table`
--

INSERT INTO `student_table` (`ID`, `Student_Name`, `Student_Email`, `Gender`, `DOB`, `Student_ID`, `Father_Name`, `Mother_Name`, `Address`, `User_Name`, `Password`, `Image`, `Date_of_Admission`, `Class_ID`, `Contact_Number`, `Alternate_Number`) VALUES
(1, 'Afaq Ahmed', 'afaqahmed@gmail.com', 'Male', '2000-06-07', '23SP-086-CS', 'Ahmed Khan', 'Raziya Begum', '12 Bury Old Road, Manchester, M8 5EL', 'afaqahmed', 'd5158ce9d2e9898e636fe2531d036537', 'a741218d355772f15509a64b581e2c361702501187.jpg', '2023-12-13 15:59:47', 2, '+446792632627', '+449808800816'),
(2, 'Sophie Harris', 'sophie.harris@gmail.com', 'Female', '2003-05-26', '23SP-128-CS', 'Oliver Harris', 'Ava Harris', '456 Elm Street, Chicago', 'sophie_harris', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 07:30:00', 2, '+446030641939', '+442337206017'),
(3, 'Ethan Lee', 'ethan.lee@gmail.com', 'Male', '2002-11-09', '23SP-129-CS', 'Benjamin Lee', 'Emily Lee', '567 Pine Street, Los Angeles', 'ethan_lee', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 08:15:00', 4, '+443594104576', '+449589051374'),
(4, 'Olivia Robinson', 'olivia.robinson@gmail.com', 'Female', '2002-04-24', '23SP-130-CS', 'Lucas Robinson', 'Layla Robinson', '678 Oak Street, San Francisco', 'olivia_robinson', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 09:00:00', 3, '+444012212263', '+447184346213'),
(5, 'Mason Davis', 'mason.davis@gmail.com', 'Male', '2001-10-08', '23SP-131-CS', 'Jackson Davis', 'Zoe Davis', '789 Elm Street, New York', 'mason_davis', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 09:45:00', 5, '+443885094582', '+447872434582'),
(6, 'Aria Garcia', 'aria.garcia@gmail.com', 'Female', '2001-03-23', '23SP-132-CS', 'Logan Garcia', 'Ava Garcia', '890 Pine Street, Miami', 'aria_garcia', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 10:30:00', 2, '+447706889470', '+444917143913'),
(7, 'Logan Taylor', 'logan.taylor@gmail.com', 'Male', '2000-08-06', '23SP-133-CS', 'Daniel Taylor', 'Sophia Taylor', '123 Cedar Street, Los Angeles', 'logan_taylor', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 11:15:00', 3, '+441465051464', '+442573825887'),
(8, 'Ava Wilson', 'ava.wilson@gmail.com', 'Female', '1999-12-21', '23SP-134-CS', 'Carter Wilson', 'Emma Wilson', '456 Elm Street, Chicago', 'ava_wilson', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 12:00:00', 5, '+448473975349', '+444648399394'),
(9, 'Elijah Turner', 'elijah.turner@gmail.com', 'Male', '1999-05-07', '23SP-135-CS', 'Owen Turner', 'Lily Turner', '567 Oak Street, San Francisco', 'elijah_turner', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 12:45:00', 4, '+447820071231', '+445155158280'),
(10, 'Aiden Patel', 'aiden.patel@gmail.com', 'Male', '2003-12-11', '23SP-127-CS', 'Elijah Patel', 'Madison Patel', '123 Cedar Street, Denver', 'aiden_patel', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 06:45:00', 2, '+441220899448', '+445938667995'),
(11, 'Kishore Sharma', 'kishore@gmail.com', 'Male', '2019-01-05', '23SP-087-CS', 'Janak Sharma', 'Indra Devi', '346 Oak Street, London', 'Kishore_Sharma', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-16 01:23:33', 5, '+448666106507', '+443904130397'),
(12, 'John Doe', 'john.doe@gmail.com', 'Male', '2018-02-10', '23SP-088-CS', 'James Doe', 'Mary Doe', '123 Maple Street, New York', 'john_doe', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-14 23:45:00', 1, '+443522332770', '+445899272967'),
(13, 'Jane Smith', 'jane.smith@gmail.com', 'Female', '2017-07-22', '23SP-089-CS', 'Robert Smith', 'Emily Smith', '456 Pine Street, Los Angeles', 'jane_smith', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 00:30:00', 3, '+448929366831', '+446949015564'),
(14, 'Michael Johnson', 'michael.johnson@gmail.com', 'Male', '2016-04-15', '23SP-090-CS', 'David Johnson', 'Laura Johnson', '789 Cedar Street, Chicago', 'michael_johnson', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 01:15:00', 3, '+447956977633', '+448937841783'),
(15, 'Eva Williams', 'eva.williams@gmail.com', 'Female', '2015-09-30', '23SP-091-CS', 'Daniel Williams', 'Olivia Williams', '567 Elm Street, San Francisco', 'eva_williams', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 02:00:00', 2, '+448182763224', '+447277856569'),
(16, 'Sophia Miller', 'sophia.miller@gmail.com', 'Female', '2018-05-12', '23SP-092-CS', 'William Miller', 'Emma Miller', '678 Walnut Street, Miami', 'sophia_miller', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 03:30:00', 1, '+443934454185', '+447838701529'),
(17, 'Oliver Brown', 'oliver.brown@gmail.com', 'Male', '2017-10-18', '23SP-093-CS', 'Christopher Brown', 'Ava Brown', '789 Pine Street, Seattle', 'oliver_brown', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 04:15:00', 1, '+447390145396', '+443434622700'),
(18, 'Lily Davis', 'lily.davis@gmail.com', 'Female', '2016-03-25', '23SP-094-CS', 'Matthew Davis', 'Sophia Davis', '890 Oak Street, Houston', 'lily_davis', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 05:00:00', 3, '+445002677622', '+444709520316'),
(19, 'Mason Wilson', 'mason.wilson@gmail.com', 'Male', '2015-08-08', '23SP-095-CS', 'Ryan Wilson', 'Isabella Wilson', '123 Cedar Street, Denver', 'mason_wilson', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 06:45:00', 3, '+448539569022', '+448569284471'),
(20, 'Aria Taylor', 'aria.taylor@gmail.com', 'Female', '2014-01-20', '23SP-096-CS', 'Ethan Taylor', 'Madison Taylor', '456 Maple Street, Dallas', 'aria_taylor', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 07:30:00', 4, '+447227715595', '+444307248725'),
(21, 'Noah Garcia', 'noah.garcia@gmail.com', 'Male', '2013-06-14', '23SP-097-CS', 'Gabriel Garcia', 'Hannah Garcia', '789 Walnut Street, Phoenix', 'noah_garcia', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 08:15:00', 2, '+444704778835', '+441060215105'),
(22, 'Mia Hernandez', 'mia.hernandez@gmail.com', 'Female', '2012-11-28', '23SP-098-CS', 'Luis Hernandez', 'Avery Hernandez', '890 Pine Street, Atlanta', 'mia_hernandez', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 09:00:00', 1, '+443889642184', '+446267565913'),
(23, 'Ethan Martinez', 'ethan.martinez@gmail.com', 'Male', '2011-04-03', '23SP-099-CS', 'Carlos Martinez', 'Zoe Martinez', '123 Elm Street, San Diego', 'ethan_martinez', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 09:45:00', 2, '+449668903322', '+449541819179'),
(24, 'Isabella Robinson', 'isabella.robinson@gmail.com', 'Female', '2010-09-17', '23SP-100-CS', 'Nathan Robinson', 'Aria Robinson', '345 Cedar Street, Orlando', 'isabella_robinson', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 10:30:00', 1, '+448702386234', '+444886473943'),
(25, 'Liam Walker', 'liam.walker@gmail.com', 'Male', '2009-02-09', '23SP-101-CS', 'Samuel Walker', 'Grace Walker', '567 Oak Street, Las Vegas', 'liam_walker', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 11:15:00', 1, '+448325211320', '+446966635079'),
(26, 'Aiden Harris', 'aiden.harris@gmail.com', 'Male', '2018-05-25', '23SP-102-CS', 'Andrew Harris', 'Ella Harris', '456 Pine Street, Boston', 'aiden_harris', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 12:00:00', 2, '+449857541741', '+448387803778'),
(27, 'Sophie Turner', 'sophie.turner@gmail.com', 'Female', '2019-11-12', '23SP-103-CS', 'David Turner', 'Sophia Turner', '789 Elm Street, Vancouver', 'sophie_turner', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 12:45:00', 3, '+442366393974', '+446668558844'),
(28, 'Henry White', 'henry.white@gmail.com', 'Male', '2020-04-08', '23SP-104-CS', 'Michael White', 'Mia White', '890 Oak Street, Sydney', 'henry_white', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 13:30:00', 1, '+446243612604', '+441212386797'),
(29, 'Emma Patel', 'emma.patel@gmail.com', 'Female', '2021-09-03', '23SP-105-CS', 'Aiden Patel', 'Lily Patel', '123 Maple Street, Toronto', 'emma_patel', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 14:15:00', 2, '+447331096480', '+443018322319'),
(30, 'Carter Kim', 'carter.kim@gmail.com', 'Male', '2022-02-18', '23SP-106-CS', 'Daniel Kim', 'Chloe Kim', '456 Cedar Street, Seoul', 'carter_kim', '7cdb42adc7eaa6b227315c7d03b26486', '646ccaec24a9ab751e1eda17f912486c1702504352.jpg', '2022-01-15 15:00:00', 3, '+443098322463', '+446436645664');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_table`
--
ALTER TABLE `admin_table`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `classes_table`
--
ALTER TABLE `classes_table`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `student_table`
--
ALTER TABLE `student_table`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `fk_class` (`Class_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_table`
--
ALTER TABLE `admin_table`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `classes_table`
--
ALTER TABLE `classes_table`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `student_table`
--
ALTER TABLE `student_table`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `classes_table`
--
ALTER TABLE `classes_table`
  ADD CONSTRAINT `classes_table_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `student_table` (`Class_ID`) ON UPDATE CASCADE;

--
-- Constraints for table `student_table`
--
ALTER TABLE `student_table`
  ADD CONSTRAINT `Student_Class_Relation` FOREIGN KEY (`Class_ID`) REFERENCES `classes_table` (`ID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
